import sys
import torch
import numpy as np
import scipy.io.wavfile as wavfile
from pydub import AudioSegment
from transformers import SpeechT5Processor, SpeechT5ForTextToSpeech, SpeechT5HifiGan
from huggingface_hub import hf_hub_download

def run_inference(message, output_path):
    # 1. Load models
    processor = SpeechT5Processor.from_pretrained("microsoft/speecht5_tts")
    model = SpeechT5ForTextToSpeech.from_pretrained("microsoft/speecht5_tts")
    vocoder = SpeechT5HifiGan.from_pretrained("microsoft/speecht5_hifigan")

    # 2. Corrected: Download the actual file present in that repo
    # The file in 'Matthijs/cmu-arctic-xvectors' is 'cmu-arctic-xvectors.bin'
    embeddings_file = hf_hub_download(
        repo_id="Matthijs/cmu-arctic-xvectors", 
        filename="cmu-arctic-xvectors.bin"
    )
    
    # Load the embeddings (a dictionary where keys are speaker IDs)
    speaker_embeddings = torch.load(embeddings_file, map_location=torch.device('cpu'))
    
    # Extract one speaker embedding (e.g., from the first speaker in the file)
    # The file is a dict; we take the first available key's value
    first_key = list(speaker_embeddings.keys())[0]
    embedding = torch.tensor(speaker_embeddings[first_key]).unsqueeze(0)

    # 3. Generate
    inputs = processor(text=message, return_tensors="pt")
    speech = model.generate_speech(inputs["input_ids"], embedding, vocoder=vocoder)
    
    # 4. Save to temporary WAV then convert to MP3
    temp_wav = "temp.wav"
    wavfile.write(temp_wav, 16000, (speech.numpy() * 32767).astype(np.int16))
    
    sound = AudioSegment.from_wav(temp_wav)
    sound.export(output_path, format="mp3")
    
    # Cleanup
    if os.path.exists(temp_wav):
        os.remove(temp_wav)

if __name__ == "__main__":
    import os
    run_inference(sys.argv[1], sys.argv[2])
